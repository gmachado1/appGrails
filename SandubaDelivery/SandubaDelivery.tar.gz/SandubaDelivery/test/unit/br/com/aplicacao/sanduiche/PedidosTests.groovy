package br.com.aplicacao.sanduiche



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Pedidos)
class PedidosTests {

    void testSomething() {
       fail "Implement me"
    }
}
