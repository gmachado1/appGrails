grails generate-all br.com.aplicacao.sanduiche.Cliente
grails generate-all br.com.aplicacao.sanduiche.Enderecos
grails generate-all br.com.aplicacao.sanduiche.Entregas
grails generate-all br.com.aplicacao.sanduiche.Funcionario
grails generate-all br.com.aplicacao.sanduiche.Pedidos
grails generate-all br.com.aplicacao.sanduiche.Produtos


echo "##########################################################################"
echo "                            Iniciando aplicacao"
echo "##########################################################################"


grails run-app
