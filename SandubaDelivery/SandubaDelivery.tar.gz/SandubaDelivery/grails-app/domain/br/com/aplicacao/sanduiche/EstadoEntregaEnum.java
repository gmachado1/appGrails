package br.com.aplicacao.sanduiche;

public enum EstadoEntregaEnum {  
	  
    SOLICITADO, ENTREGUE, EM_ANDAMENTO
}  
