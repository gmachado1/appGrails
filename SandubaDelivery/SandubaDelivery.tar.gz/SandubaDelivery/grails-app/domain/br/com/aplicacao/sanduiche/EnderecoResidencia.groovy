package br.com.aplicacao.sanduiche

class EnderecoResidencia extends Enderecos {

	static belongsTo= [pessoa:Pessoas]	

}
