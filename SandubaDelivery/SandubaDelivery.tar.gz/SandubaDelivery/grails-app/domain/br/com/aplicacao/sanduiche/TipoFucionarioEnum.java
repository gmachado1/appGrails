package br.com.aplicacao.sanduiche;

public enum TipoFucionarioEnum {
	
	MOTOCICLISTA,
	RECEPCIONISTA, 
	CUZINHEIRA,
	FAXINEIRA;

}
